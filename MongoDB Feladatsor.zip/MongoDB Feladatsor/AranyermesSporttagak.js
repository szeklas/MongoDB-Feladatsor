var MongoClient=require("mongodb").MongoClient
var url="mongodb+srv://t13szeklas:12345asd@cluster0.njg294g.mongodb.net/"

async function AranyermesSporttagak(){
    try{
        const client=await MongoClient.connect(url)
        const db=client.db("T13")
        const collection=db.collection("Helsinki")

        const keresesiMinta={helyezes:"1"}
        const eredmeny=await collection.find(keresesiMinta,{projection:{_id:0,sportag:1,helyezes:1}}).toArray()
        
        console.log("Sikeres kiiratás",eredmeny)
        client.close()
    }
    catch(err){
        console.error("Hiba a művelet végrehajtása során",err)
    }
}
AranyermesSporttagak()