var MongoClient=require("mongodb").MongoClient
var url="mongodb+srv://t13szeklas:12345asd@cluster0.njg294g.mongodb.net/"

async function UszasTorna(){
    try{
        const client=await MongoClient.connect(url)
        const db=client.db("T13")
        const collection=db.collection("Helsinki")

        const eredmeny=await collection.find({
            sportag:{
                $in:["torna","uszas"]
            }
        },{projection:{_id:0,sportag:1,versenyszam:1}}).toArray()
        console.log("Úszás vagy torna eredménye: ",eredmeny)
        client.close()
    }
    catch(err){
        console.error("Hiba a művelet végrehajtása során",err)
    }
}
UszasTorna()