var MongoClient=require("mongodb").MongoClient
var url="mongodb+srv://t13szeklas:12345asd@cluster0.njg294g.mongodb.net/"

async function CreateCollection(){
    try{
        const client=await MongoClient.connect(url)
        const db=client.db("T13")
        await db.createCollection("Helsinki")
        console.log("Kollekció sikeresen létrehozva")
        client.close()
    }
    catch(err){
        console.error("Hiba a művelet végrehajtása során",err)
    }
}
CreateCollection()